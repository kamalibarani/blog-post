from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from .models import BlogPost
from django.contrib import messages

# Home
def home(request):
    posts = BlogPost.objects.all().order_by('-created_at')
    return render(request, 'blog/home.html', {'posts': posts})

# Signup
def signup_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')  # use .get() instead of ['email']
        password = request.POST.get('password')
        
        if not username or not password:
            return render(request, 'signup.html', {'error': 'All fields required!'})

        user = User.objects.create_user(username=username, email=email, password=password)
        return redirect('login')

    return render(request, 'signup.html')


# Login
def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('dashboard')
        else:
            messages.error(request, 'Invalid credentials.')
    return render(request, 'blog/login.html')

# Logout
def logout_view(request):
    logout(request)
    return redirect('login')

# Dashboard (protected)
@login_required(login_url='login')
def dashboard(request):
    posts = BlogPost.objects.filter(author=request.user)
    return render(request, 'blog/dashboard.html', {'posts': posts})

# Create post
@login_required(login_url='login')
def create_post(request):
    if request.method == 'POST':
        title = request.POST['title']
        content = request.POST['content']
        image = request.FILES.get('image')
        BlogPost.objects.create(author=request.user, title=title, content=content, image=image)
        return redirect('dashboard')
    return render(request, 'blog/create_post.html')

# Post detail
def post_detail(request, pk):
    post = get_object_or_404(BlogPost, pk=pk)
    return render(request, 'blog/post_detail.html', {'post': post})
